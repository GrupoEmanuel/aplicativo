import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export interface Playlist {
    id: string;
    name: string;
    musicIds: string[];
    createdAt: number;
    isShared?: boolean;
    ownerId?: string;
    transpositions?: Record<string, number>;
}

interface LocalUserContextType {
    localPins: string[];
    toggleLocalPin: (musicId: string) => void;
    isLocalPinned: (musicId: string) => boolean;
    playlists: Playlist[];
    createPlaylist: (name: string) => Playlist;
    deletePlaylist: (id: string) => void;
    updatePlaylist: (id: string, updates: Partial<Playlist>) => void;
    addToPlaylist: (playlistId: string, musicId: string) => void;
    removeFromPlaylist: (playlistId: string, musicId: string) => void;
    reorderPlaylist: (playlistId: string, musicId: string, direction: 'up' | 'down') => void;
    savePlaylist: (name: string, musicIds: string[]) => void;
    importPlaylist: (playlist: Playlist) => void;
    userId: string;
    savedTranspositions: Record<string, number>;
    updateGlobalTransposition: (musicId: string, steps: number) => void;
}

const LocalUserContext = createContext<LocalUserContextType | undefined>(undefined);

export const LocalUserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // User ID for ownership
    const [userId] = useState<string>(() => {
        const saved = localStorage.getItem('user_id');
        if (saved) return saved;
        const newId = crypto.randomUUID();
        localStorage.setItem('user_id', newId);
        return newId;
    });

    // Local Pins
    const [localPins, setLocalPins] = useState<string[]>(() => {
        const saved = localStorage.getItem('user_local_pins');
        return saved ? JSON.parse(saved) : [];
    });

    // Playlists
    const [playlists, setPlaylists] = useState<Playlist[]>(() => {
        const saved = localStorage.getItem('user_playlists');
        return saved ? JSON.parse(saved) : [];
    });

    // Global Transpositions
    const [savedTranspositions, setSavedTranspositions] = useState<Record<string, number>>(() => {
        const saved = localStorage.getItem('user_transpositions');
        return saved ? JSON.parse(saved) : {};
    });

    useEffect(() => {
        localStorage.setItem('user_local_pins', JSON.stringify(localPins));
    }, [localPins]);

    useEffect(() => {
        localStorage.setItem('user_playlists', JSON.stringify(playlists));
    }, [playlists]);

    useEffect(() => {
        localStorage.setItem('user_transpositions', JSON.stringify(savedTranspositions));
    }, [savedTranspositions]);

    const toggleLocalPin = (musicId: string) => {
        setLocalPins(prev =>
            prev.includes(musicId)
                ? prev.filter(id => id !== musicId)
                : [...prev, musicId]
        );
    };

    const isLocalPinned = (musicId: string) => localPins.includes(musicId);

    const updateGlobalTransposition = (musicId: string, steps: number) => {
        setSavedTranspositions(prev => ({
            ...prev,
            [musicId]: steps
        }));
    };

    const createPlaylist = (name: string) => {
        const newPlaylist: Playlist = {
            id: crypto.randomUUID(),
            name,
            musicIds: [],
            createdAt: Date.now(),
            transpositions: {}
        };
        setPlaylists(prev => [...prev, newPlaylist]);
        return newPlaylist;
    };

    const savePlaylist = (name: string, musicIds: string[]) => {
        const newPlaylist: Playlist = {
            id: crypto.randomUUID(),
            name,
            musicIds,
            createdAt: Date.now(),
            transpositions: {}
        };
        setPlaylists(prev => [...prev, newPlaylist]);
    };

    const importPlaylist = (playlist: Playlist) => {
        const newPlaylist: Playlist = {
            ...playlist,
            id: crypto.randomUUID(),
            createdAt: Date.now(),
            isShared: true
        };
        setPlaylists(prev => [...prev, newPlaylist]);
    };

    const deletePlaylist = (id: string) => {
        setPlaylists(prev => prev.filter(p => p.id !== id));
    };

    const updatePlaylist = (id: string, updates: Partial<Playlist>) => {
        setPlaylists(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
    };

    const addToPlaylist = (playlistId: string, musicId: string) => {
        setPlaylists(prev => prev.map(p => {
            if (p.id === playlistId && !p.musicIds.includes(musicId)) {
                const currentTransposition = savedTranspositions[musicId] || 0;
                return {
                    ...p,
                    musicIds: [...p.musicIds, musicId],
                    transpositions: {
                        ...(p.transpositions || {}),
                        [musicId]: currentTransposition
                    }
                };
            }
            return p;
        }));
    };

    const removeFromPlaylist = (playlistId: string, musicId: string) => {
        setPlaylists(prev => prev.map(p => {
            if (p.id === playlistId) {
                const newTranspositions = { ...(p.transpositions || {}) };
                delete newTranspositions[musicId];
                return {
                    ...p,
                    musicIds: p.musicIds.filter(id => id !== musicId),
                    transpositions: newTranspositions
                };
            }
            return p;
        }));
    };

    const reorderPlaylist = (playlistId: string, musicId: string, direction: 'up' | 'down') => {
        setPlaylists(prev => prev.map(p => {
            if (p.id === playlistId) {
                const currentIndex = p.musicIds.indexOf(musicId);
                if (currentIndex === -1) return p;

                const newMusicIds = [...p.musicIds];

                // Circular behavior - no limits
                if (direction === 'up') {
                    const newIndex = currentIndex === 0 ? newMusicIds.length - 1 : currentIndex - 1;
                    [newMusicIds[currentIndex], newMusicIds[newIndex]] = [newMusicIds[newIndex], newMusicIds[currentIndex]];
                } else {
                    const newIndex = currentIndex === newMusicIds.length - 1 ? 0 : currentIndex + 1;
                    [newMusicIds[currentIndex], newMusicIds[newIndex]] = [newMusicIds[newIndex], newMusicIds[currentIndex]];
                }

                return { ...p, musicIds: newMusicIds };
            }
            return p;
        }));
    };

    return (
        <LocalUserContext.Provider value={{
            localPins,
            toggleLocalPin,
            isLocalPinned,
            playlists,
            createPlaylist,
            deletePlaylist,
            updatePlaylist,
            addToPlaylist,
            removeFromPlaylist,
            reorderPlaylist,
            savePlaylist,
            importPlaylist,
            userId,
            savedTranspositions,
            updateGlobalTransposition
        }}>
            {children}
        </LocalUserContext.Provider>
    );
};

export const useLocalUserData = () => {
    const context = useContext(LocalUserContext);
    if (context === undefined) {
        throw new Error('useLocalUserData must be used within a LocalUserProvider');
    }
    return context;
};
